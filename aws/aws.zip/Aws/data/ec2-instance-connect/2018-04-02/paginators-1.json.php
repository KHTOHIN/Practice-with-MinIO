<?php
// This file was auto-generated from sdk-root/src/data/ec2-instance-connect/2018-04-02/paginators-1.json
return [ 'pagination' => [],];
