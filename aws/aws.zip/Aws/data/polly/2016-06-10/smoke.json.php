<?php
// This file was auto-generated from sdk-root/src/data/polly/2016-06-10/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeVoices', 'input' => [], 'errorExpectedFromService' => false, ], ],];
