<?php
// This file was auto-generated from sdk-root/src/data/controltower/2018-05-10/paginators-1.json
return [ 'pagination' => [ 'ListEnabledControls' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'enabledControls', ], ],];
