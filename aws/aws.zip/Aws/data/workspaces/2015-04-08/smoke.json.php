<?php
// This file was auto-generated from sdk-root/src/data/workspaces/2015-04-08/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeWorkspaces', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeWorkspaces', 'input' => [ 'DirectoryId' => 'fake-id', ], 'errorExpectedFromService' => true, ], ],];
