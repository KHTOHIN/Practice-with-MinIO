<?php
// This file was auto-generated from sdk-root/src/data/lightsail/2016-11-28/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'GetActiveNames', 'input' => [], 'errorExpectedFromService' => false, ], ],];
